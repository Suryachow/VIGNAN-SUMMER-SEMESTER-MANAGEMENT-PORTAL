
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// Set a global background image for the entire application
document.body.style.margin = '0';
document.body.style.padding = '0';
document.body.style.backgroundImage = 'url("/lovable-uploads/e9091c9e-d2ac-46c4-827a-b3ac83c8d281.png")';
document.body.style.backgroundSize = 'cover';
document.body.style.backgroundPosition = 'center';
document.body.style.backgroundAttachment = 'fixed';
document.body.style.backgroundColor = 'rgba(255, 255, 255, 0.7)'; // Add a white overlay with 70% opacity
document.body.style.backgroundBlendMode = 'overlay';

createRoot(document.getElementById("root")!).render(<App />);
