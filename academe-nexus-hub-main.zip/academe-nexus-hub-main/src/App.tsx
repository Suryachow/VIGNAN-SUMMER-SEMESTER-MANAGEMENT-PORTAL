
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import { CourseProvider } from "@/context/CourseContext";
import { RegistrationProvider } from "@/context/RegistrationContext";
import { NotificationProvider } from "@/context/NotificationContext";
import { BacklogProvider } from "@/context/BacklogContext";
import { PaymentProvider } from "@/context/PaymentContext";
import { ReportProvider } from "@/context/ReportContext";
import { UserProvider } from "@/context/UserContext";

import DashboardLayout from "@/components/layout/DashboardLayout";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Courses from "./pages/Courses";
import CourseDetails from "./pages/CourseDetails";
import NotFound from "./pages/NotFound";
import UserManagement from "./pages/UserManagement";
import Registrations from "./pages/Registrations";
import Reports from "./pages/Reports";
import Payments from "./pages/Payments";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Backlogs from "./pages/Backlogs";
import Students from "./pages/Students";
import { useAuth } from "./context/AuthContext";

// Route guard component for role-based access
const RoleRoute = ({ children, allowedRoles }) => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <Navigate to="/auth" replace />;
  }
  
  if (allowedRoles.includes(currentUser.role)) {
    return <>{children}</>;
  }
  
  return <Navigate to="/dashboard" replace />;
};

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <CourseProvider>
        <RegistrationProvider>
          <NotificationProvider>
            <BacklogProvider>
              <PaymentProvider>
                <ReportProvider>
                  <UserProvider>
                    <TooltipProvider>
                      <Toaster />
                      <Sonner />
                      <BrowserRouter>
                        <Routes>
                          <Route path="/" element={<Index />} />
                          <Route path="/auth" element={<Auth />} />
                          
                          {/* Dashboard routes */}
                          <Route path="/" element={<DashboardLayout />}>
                            <Route path="/dashboard" element={<Dashboard />} />
                            
                            {/* Student Routes */}
                            <Route path="/courses" element={<Courses />} />
                            <Route path="/course/:id" element={<CourseDetails />} />
                            <Route path="/registrations" element={<Registrations />} />
                            <Route path="/backlogs" element={<Backlogs />} />
                            <Route path="/payments" element={<Payments />} />
                            
                            {/* Admin Routes */}
                            <Route 
                              path="/users" 
                              element={
                                <RoleRoute allowedRoles={['admin']}>
                                  <UserManagement />
                                </RoleRoute>
                              } 
                            />
                            <Route 
                              path="/students" 
                              element={
                                <RoleRoute allowedRoles={['admin', 'faculty']}>
                                  <Students />
                                </RoleRoute>
                              } 
                            />
                            <Route 
                              path="/reports" 
                              element={
                                <RoleRoute allowedRoles={['admin', 'faculty']}>
                                  <Reports />
                                </RoleRoute>
                              } 
                            />
                            
                            {/* Common Routes */}
                            <Route path="/profile" element={<Profile />} />
                            <Route path="/settings" element={<Settings />} />
                          </Route>
                          
                          {/* Catch-all route */}
                          <Route path="*" element={<NotFound />} />
                        </Routes>
                      </BrowserRouter>
                    </TooltipProvider>
                  </UserProvider>
                </ReportProvider>
              </PaymentProvider>
            </BacklogProvider>
          </NotificationProvider>
        </RegistrationProvider>
      </CourseProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
