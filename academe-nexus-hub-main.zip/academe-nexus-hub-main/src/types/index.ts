
export type UserRole = 'student' | 'faculty' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  profileImage?: string;
  status?: 'Active' | 'Inactive';
  lastActive?: string;
  department?: string;
  joinedDate?: string;
  cgpa?: number;
}

export interface Course {
  id: string;
  code: string;
  name: string;
  description: string;
  credits: number;
  department: string;
  instructor: string;
  instructorId: string;
  maxStudents: number;
  currentStudents: number;
  schedule: string;
  startDate: string;
  endDate: string;
  isSummerCourse: boolean;
  isBacklogCourse: boolean;
  fee: number;
}

export interface Registration {
  id: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseName: string;
  registrationDate: string;
  status: 'pending' | 'approved' | 'rejected';
  paymentStatus: 'pending' | 'completed';
  paymentId?: string;
  approvedBy?: string;
  approvalDate?: string;
  rejectionReason?: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  createdAt: string;
  isRead: boolean;
  type: 'registration' | 'payment' | 'approval' | 'general';
  link?: string;
}

export interface StudentBacklog {
  id: string;
  studentId: string;
  courseId: string;
  courseName: string;
  semester: string;
  academicYear: string;
  status: 'pending' | 'registered' | 'completed' | 'failed';
  registrationId?: string;
}

export interface Payment {
  id: string;
  userId: string;
  registrationId: string;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  transactionId?: string;
  paymentDate: string;
  paymentMethod: string;
}

export interface Report {
  id: string;
  title: string;
  description: string;
  generatedBy: string;
  generatedDate: string;
  type: 'registration' | 'completion' | 'backlog' | 'payment';
  data: any;
}
