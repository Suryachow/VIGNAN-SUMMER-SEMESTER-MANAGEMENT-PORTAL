
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Course } from '@/types';
import { toast } from 'sonner';

interface CourseContextType {
  courses: Course[];
  summerCourses: Course[];
  backlogCourses: Course[];
  isLoading: boolean;
  addCourse: (course: Omit<Course, 'id'>) => Promise<Course>;
  updateCourse: (id: string, courseData: Partial<Course>) => Promise<Course | null>;
  deleteCourse: (id: string) => Promise<boolean>;
  getCourseById: (id: string) => Course | undefined;
  sortCourses: (key: keyof Course, order: 'asc' | 'desc') => void;
  filterCoursesByDepartment: (department: string | null) => void;
}

const CourseContext = createContext<CourseContextType | undefined>(undefined);

// Mock course data for demo
const MOCK_COURSES: Course[] = [
  {
    id: '1',
    code: 'CS101',
    name: 'Introduction to Computer Science',
    description: 'A foundational course covering basic programming concepts and computer science principles.',
    credits: 3,
    department: 'Computer Science',
    instructor: 'Dr. Alan Turing',
    instructorId: '2',
    maxStudents: 30,
    currentStudents: 12,
    schedule: 'Mon, Wed, Fri 10:00 AM - 11:30 AM',
    startDate: '2023-06-01',
    endDate: '2023-07-15',
    isSummerCourse: true,
    isBacklogCourse: false,
    fee: 12000,
  },
  {
    id: '2',
    code: 'MATH201',
    name: 'Calculus II',
    description: 'Continuation of Calculus I, covering integration techniques, applications, and series.',
    credits: 4,
    department: 'Mathematics',
    instructor: 'Dr. Katherine Johnson',
    instructorId: '2',
    maxStudents: 25,
    currentStudents: 18,
    schedule: 'Tue, Thu 9:00 AM - 11:00 AM',
    startDate: '2023-06-01',
    endDate: '2023-07-15',
    isSummerCourse: true,
    isBacklogCourse: true,
    fee: 15000,
  },
  {
    id: '3',
    code: 'PHYS102',
    name: 'Physics for Engineers',
    description: 'Introduction to mechanics, electricity, and magnetism for engineering students.',
    credits: 4,
    department: 'Physics',
    instructor: 'Dr. Richard Feynman',
    instructorId: '2',
    maxStudents: 30,
    currentStudents: 22,
    schedule: 'Mon, Wed 1:00 PM - 3:00 PM, Fri 1:00 PM - 2:00 PM',
    startDate: '2023-06-01',
    endDate: '2023-07-15',
    isSummerCourse: true,
    isBacklogCourse: false,
    fee: 14000,
  },
  {
    id: '4',
    code: 'ENG205',
    name: 'Technical Writing',
    description: 'Develop skills in writing technical reports, documentation, and professional communications.',
    credits: 3,
    department: 'English',
    instructor: 'Prof. Margaret Atwood',
    instructorId: '2',
    maxStudents: 20,
    currentStudents: 15,
    schedule: 'Tue, Thu 1:00 PM - 2:30 PM',
    startDate: '2023-06-01',
    endDate: '2023-07-15',
    isSummerCourse: false,
    isBacklogCourse: true,
    fee: 10000,
  },
  {
    id: '5',
    code: 'CS350',
    name: 'Database Systems',
    description: 'Design and implementation of database systems, focusing on relational databases and SQL.',
    credits: 3,
    department: 'Computer Science',
    instructor: 'Dr. Grace Hopper',
    instructorId: '2',
    maxStudents: 25,
    currentStudents: 20,
    schedule: 'Mon, Wed 3:00 PM - 4:30 PM',
    startDate: '2023-06-01',
    endDate: '2023-07-15',
    isSummerCourse: true,
    isBacklogCourse: true,
    fee: 13000,
  },
];

export const CourseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [filteredCourses, setFilteredCourses] = useState<Course[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeDepartmentFilter, setActiveDepartmentFilter] = useState<string | null>(null);

  useEffect(() => {
    // Simulate fetching from an API
    const fetchCourses = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        setCourses(MOCK_COURSES);
        setFilteredCourses(MOCK_COURSES);
      } catch (error) {
        toast.error('Failed to load courses. Please refresh the page.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchCourses();
  }, []);

  // Filter courses by department
  const filterCoursesByDepartment = (department: string | null) => {
    setActiveDepartmentFilter(department);
    if (!department) {
      setFilteredCourses(courses);
    } else {
      setFilteredCourses(courses.filter(course => course.department === department));
    }
  };

  // Sort courses by a specific key
  const sortCourses = (key: keyof Course, order: 'asc' | 'desc') => {
    const sortedCourses = [...filteredCourses].sort((a, b) => {
      if (typeof a[key] === 'string' && typeof b[key] === 'string') {
        return order === 'asc' 
          ? (a[key] as string).localeCompare(b[key] as string)
          : (b[key] as string).localeCompare(a[key] as string);
      } else if (typeof a[key] === 'number' && typeof b[key] === 'number') {
        return order === 'asc' 
          ? (a[key] as number) - (b[key] as number)
          : (b[key] as number) - (a[key] as number);
      }
      return 0;
    });
    
    setFilteredCourses(sortedCourses);
  };

  const summerCourses = filteredCourses.filter(course => course.isSummerCourse);
  const backlogCourses = filteredCourses.filter(course => course.isBacklogCourse);

  const addCourse = async (courseData: Omit<Course, 'id'>): Promise<Course> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const newCourse: Course = {
        ...courseData,
        id: String(Math.random().toString(36).substr(2, 9)),
      };
      
      setCourses(prevCourses => [...prevCourses, newCourse]);
      toast.success(`Course "${newCourse.name}" added successfully.`);
      return newCourse;
    } catch (error) {
      toast.error('Failed to add course. Please try again.');
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const updateCourse = async (id: string, courseData: Partial<Course>): Promise<Course | null> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      let updatedCourse: Course | null = null;
      
      setCourses(prevCourses => {
        return prevCourses.map(course => {
          if (course.id === id) {
            updatedCourse = { ...course, ...courseData };
            return updatedCourse;
          }
          return course;
        });
      });
      
      if (updatedCourse) {
        toast.success(`Course "${updatedCourse.name}" updated successfully.`);
        return updatedCourse;
      } else {
        toast.error('Course not found.');
        return null;
      }
    } catch (error) {
      toast.error('Failed to update course. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteCourse = async (id: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const courseToDelete = courses.find(course => course.id === id);
      
      if (!courseToDelete) {
        toast.error('Course not found.');
        return false;
      }
      
      setCourses(prevCourses => prevCourses.filter(course => course.id !== id));
      toast.success(`Course "${courseToDelete.name}" deleted successfully.`);
      return true;
    } catch (error) {
      toast.error('Failed to delete course. Please try again.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const getCourseById = (id: string): Course | undefined => {
    return courses.find(course => course.id === id);
  };

  const value = {
    courses: filteredCourses,
    summerCourses,
    backlogCourses,
    isLoading,
    addCourse,
    updateCourse,
    deleteCourse,
    getCourseById,
    sortCourses,
    filterCoursesByDepartment,
  };

  return <CourseContext.Provider value={value}>{children}</CourseContext.Provider>;
};

export const useCourses = () => {
  const context = useContext(CourseContext);
  if (context === undefined) {
    throw new Error('useCourses must be used within a CourseProvider');
  }
  return context;
};
