import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover:-translate-y-0.5 active:translate-y-0",
  {
    variants: {
      variant: {
        default: "bg-gradient-to-r from-primary to-accent text-primary-foreground hover:shadow-md",
        destructive: "bg-gradient-to-r from-destructive to-red-500 text-destructive-foreground hover:shadow-md",
        outline: "border border-input bg-background hover:bg-accent/10 hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent/10 hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        brand: "bg-gradient-to-r from-brand-600 to-brand-500 text-white hover:shadow-md",
        purple: "bg-gradient-purple text-white hover:shadow-md",
        blue: "bg-gradient-ocean text-white hover:shadow-md",
        green: "bg-gradient-mojito text-white hover:shadow-md",
        amber: "bg-gradient-golden text-white hover:shadow-md",
        rose: "bg-gradient-sunset text-white hover:shadow-md",
        colorful: "bg-gradient-neon text-white hover:shadow-md",
        candy: "bg-gradient-candy text-white hover:shadow-md",
        ocean: "bg-gradient-ocean text-white hover:shadow-md",
        sunset: "bg-gradient-sunset text-white hover:shadow-md",
        mojito: "bg-gradient-mojito text-white hover:shadow-md",
        space: "bg-gradient-space text-white hover:shadow-md",
        glow: "bg-gradient-to-r from-primary to-accent text-primary-foreground hover:shadow-lg shadow-primary/40",
        vibrant: "bg-gradient-to-r from-neon-orange to-neon-pink text-white hover:shadow-lg shadow-neon-orange/40 border border-white/30",
        neon: "bg-black text-neon-green border-2 border-neon-green shadow-[0_0_10px_#0FFF50] hover:shadow-[0_0_20px_#0FFF50]",
        contrast: "bg-black text-white border-2 border-white font-bold hover:bg-white hover:text-black transition-colors",
        elegant: "bg-white text-brand-800 border border-brand-200 shadow-md hover:bg-brand-50 hover:shadow-lg transition-all",
        soft: "bg-white text-brand-700 border border-brand-100 shadow-sm hover:bg-brand-25 hover:shadow-md transition-colors",
        glass: "bg-white/80 backdrop-blur-md text-brand-900 border border-white/30 shadow-xl hover:bg-white/90 transition-all",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        xl: "h-12 rounded-md px-10 text-base",
        icon: "h-10 w-10",
        xxl: "h-14 rounded-md px-12 text-lg font-bold",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
