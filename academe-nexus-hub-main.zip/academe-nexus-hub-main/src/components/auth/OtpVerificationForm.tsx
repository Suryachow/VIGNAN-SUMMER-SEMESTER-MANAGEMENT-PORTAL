
import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface OtpVerificationFormProps {
  email: string;
  onSwitchToResetPassword: () => void;
  onSwitchToLogin: () => void;
}

const OtpVerificationForm: React.FC<OtpVerificationFormProps> = ({ 
  email, 
  onSwitchToResetPassword, 
  onSwitchToLogin 
}) => {
  const { verifyOtp, isLoading } = useAuth();
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Initialize refs array
  useEffect(() => {
    inputRefs.current = inputRefs.current.slice(0, 6);
  }, []);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) {
      value = value.substring(0, 1);
    }
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const otpString = otp.join('');
    if (otpString.length !== 6) {
      toast.error('Please enter a valid 6-digit OTP');
      return;
    }
    
    const success = await verifyOtp(email, otpString);
    if (success) {
      onSwitchToResetPassword();
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold text-center">Verify OTP</CardTitle>
        <CardDescription className="text-center">
          We've sent a 6-digit code to {email}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex justify-center space-x-2">
            {otp.map((digit, index) => (
              <Input
                key={index}
                ref={(el) => (inputRefs.current[index] = el)}
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={1}
                className="w-12 h-12 text-center text-lg"
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                required
              />
            ))}
          </div>
          <Button type="submit" className="w-full" disabled={isLoading || otp.join('').length !== 6}>
            {isLoading ? 'Verifying...' : 'Verify OTP'}
          </Button>
        </form>
        <div className="mt-4 text-center">
          <p className="text-sm text-gray-500">
            Didn't receive the code?{' '}
            <button
              type="button"
              className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
              onClick={() => toast.success('A new OTP has been sent to your email')}
            >
              Resend
            </button>
          </p>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col">
        <div className="text-sm text-center">
          <button
            type="button"
            onClick={onSwitchToLogin}
            className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
          >
            Back to login
          </button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default OtpVerificationForm;
