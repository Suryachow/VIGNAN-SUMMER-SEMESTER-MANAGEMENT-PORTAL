
import React from 'react';
import { useNotifications } from '@/context/NotificationContext';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Check, Trash } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';

const NotificationList: React.FC = () => {
  const { 
    notifications, 
    markAsRead, 
    markAllAsRead, 
    deleteNotification,
    isLoading 
  } = useNotifications();

  const handleMarkAsRead = (id: string) => {
    markAsRead(id);
  };

  const handleDeleteNotification = (id: string) => {
    deleteNotification(id);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (notifications.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 p-4">
        <p className="text-gray-500 text-center">No notifications yet</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-2 border-b border-gray-200">
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full text-xs"
          onClick={() => markAllAsRead()}
        >
          <Check className="h-3.5 w-3.5 mr-1" />
          Mark all as read
        </Button>
      </div>
      <ScrollArea className="flex-1">
        <div className="divide-y divide-gray-100">
          {notifications.map((notification) => (
            <div 
              key={notification.id} 
              className={`notification-item ${!notification.isRead ? 'notification-new' : ''}`}
            >
              <div className="flex justify-between">
                <div className="flex-1">
                  <h4 className="text-sm font-medium">
                    {notification.title}
                  </h4>
                  <p className="text-xs text-gray-500 mt-1">
                    {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                  </p>
                </div>
                <div className="flex items-start space-x-1">
                  {!notification.isRead && (
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6"
                      onClick={() => handleMarkAsRead(notification.id)}
                    >
                      <Check className="h-3.5 w-3.5" />
                    </Button>
                  )}
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6 text-red-500"
                    onClick={() => handleDeleteNotification(notification.id)}
                  >
                    <Trash className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
              <p className="text-sm mt-1">
                {notification.message}
              </p>
              {notification.link && (
                <Link 
                  to={notification.link} 
                  className="text-xs text-blue-600 hover:text-blue-800 mt-2 inline-block"
                >
                  View details
                </Link>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default NotificationList;
