
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCourses } from '@/context/CourseContext';
import { useRegistrations } from '@/context/RegistrationContext';
import { useAuth } from '@/context/AuthContext';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { 
  BookOpen, 
  CalendarDays, 
  Clock, 
  DollarSign, 
  GraduationCap, 
  User, 
  Users, 
  ArrowLeft, 
  Building2 
} from 'lucide-react';

const CourseDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getCourseById, isLoading: coursesLoading } = useCourses();
  const { createRegistration, userRegistrations, isLoading: registrationsLoading } = useRegistrations();
  const { currentUser } = useAuth();
  const [isRegistering, setIsRegistering] = useState(false);

  const course = id ? getCourseById(id) : undefined;
  
  // Check if user is already registered
  const isRegistered = userRegistrations.some(reg => reg.courseId === id);

  const handleRegister = async () => {
    if (!currentUser) {
      toast.error('Please log in to register for this course');
      return;
    }
    
    if (!course) {
      toast.error('Course information not available');
      return;
    }

    setIsRegistering(true);
    try {
      const result = await createRegistration(course.id, course.name);
      if (result) {
        toast.success('Successfully registered for the course');
      }
    } catch (error) {
      toast.error('Failed to register for the course');
    } finally {
      setIsRegistering(false);
    }
  };

  if (coursesLoading || registrationsLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="space-y-4">
        <Button 
          variant="ghost" 
          className="flex items-center gap-2" 
          onClick={() => navigate('/courses')}
        >
          <ArrowLeft size={16} /> Back to Courses
        </Button>
        
        <Card className="text-center py-12">
          <CardContent>
            <h2 className="text-xl font-semibold text-gray-700">Course not found</h2>
            <p className="text-gray-500 mt-2">The course you're looking for doesn't exist or has been removed.</p>
            <Button 
              className="mt-6"
              onClick={() => navigate('/courses')}
            >
              Browse Available Courses
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Button 
        variant="ghost" 
        className="flex items-center gap-2" 
        onClick={() => navigate('/courses')}
      >
        <ArrowLeft size={16} /> Back to Courses
      </Button>
      
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between">
                <Badge variant="outline" className="mb-1">{course.code}</Badge>
                {course.isSummerCourse && <Badge>Summer Course</Badge>}
                {course.isBacklogCourse && <Badge variant="destructive">Backlog Course</Badge>}
              </div>
              <CardTitle>{course.name}</CardTitle>
              <CardDescription>{course.department}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Course Description</h3>
                <p className="text-gray-700">{course.description}</p>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start gap-2">
                  <GraduationCap className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Credits</h4>
                    <p className="text-gray-600">{course.credits} credits</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-2">
                  <Building2 className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Department</h4>
                    <p className="text-gray-600">{course.department}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-2">
                  <User className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Instructor</h4>
                    <p className="text-gray-600">{course.instructor}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-2">
                  <Users className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Enrollment</h4>
                    <p className="text-gray-600">{course.currentStudents}/{course.maxStudents} students</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-2">
                  <CalendarDays className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Course Duration</h4>
                    <p className="text-gray-600">
                      {new Date(course.startDate).toLocaleDateString()} - {new Date(course.endDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-2">
                  <Clock className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Schedule</h4>
                    <p className="text-gray-600">{course.schedule}</p>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Course Materials</h3>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-blue-500" />
                  <span className="text-blue-600 hover:underline cursor-pointer">
                    View Course Syllabus
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Registration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="font-medium">Course Fee:</span>
                <span className="font-bold">₹{course.fee.toLocaleString()}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="font-medium">Registration Status:</span>
                <span>
                  {isRegistered ? (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Registered
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                      Not Registered
                    </Badge>
                  )}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="font-medium">Seats Available:</span>
                <span>{course.maxStudents - course.currentStudents} of {course.maxStudents}</span>
              </div>
              
              <Separator />
              
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-gray-500" />
                <span className="text-sm text-gray-700">
                  Payment can be made after registration is approved
                </span>
              </div>
            </CardContent>
            <CardFooter>
              {currentUser && currentUser.role === 'student' ? (
                isRegistered ? (
                  <Button disabled variant="outline" className="w-full">
                    Already Registered
                  </Button>
                ) : (
                  <Button 
                    className="w-full" 
                    onClick={handleRegister}
                    disabled={isRegistering}
                  >
                    {isRegistering ? 'Registering...' : 'Register Now'}
                  </Button>
                )
              ) : (
                <Button asChild className="w-full">
                  <a href="/auth">Login to Register</a>
                </Button>
              )}
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Course Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="font-medium">Course Code:</span>
                <span>{course.code}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="font-medium">Credits:</span>
                <span>{course.credits}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="font-medium">Department:</span>
                <span>{course.department}</span>
              </div>
              
              <Separator />
              
              <div className="rounded-md bg-blue-50 p-3">
                <h4 className="text-sm font-medium text-blue-800 mb-1">Important Note</h4>
                <p className="text-xs text-blue-700">
                  Students with prior academic holds may need additional clearance from the academic office before registration.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CourseDetails;
