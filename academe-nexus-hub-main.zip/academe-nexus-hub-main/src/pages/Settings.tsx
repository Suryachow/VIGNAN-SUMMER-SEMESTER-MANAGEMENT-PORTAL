
import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';
import { 
  Bell, 
  Lock, 
  Eye, 
  EyeOff, 
  Mail, 
  Smartphone, 
  Globe, 
  Moon, 
  Info, 
  ShieldCheck, 
  LogOut 
} from 'lucide-react';

const Settings = () => {
  const { toast } = useToast();
  const { logout } = useAuth();
  
  // Password state
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Notification preferences
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    smsNotifications: false,
    registrationUpdates: true,
    paymentReminders: true,
    courseAnnouncements: true,
    generalUpdates: false,
  });
  
  // Display preferences
  const [displaySettings, setDisplaySettings] = useState({
    language: 'english',
    theme: 'light',
    compactView: false,
    highContrast: false,
    fontSize: 'medium',
  });
  
  const handlePasswordChange = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    toast({
      title: "Password updated",
      description: "Your password has been changed successfully. Please use your new password for future logins.",
    });
  };
  
  const handleNotificationSettingChange = (key: string, value: boolean) => {
    setNotificationSettings(prev => ({
      ...prev,
      [key]: value
    }));
    
    toast({
      title: "Notification settings updated",
      description: `${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} have been ${value ? 'enabled' : 'disabled'}.`,
    });
  };
  
  const handleDisplaySettingChange = (key: string, value: string | boolean) => {
    setDisplaySettings(prev => ({
      ...prev,
      [key]: value
    }));
    
    toast({
      title: "Display settings updated",
      description: `Your display preferences have been updated.`,
    });
  };
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-brand-800">Settings</h1>
      </div>
      
      <Tabs defaultValue="account" className="space-y-6">
        <TabsList className="flex h-auto flex-col sm:flex-row space-x-0 sm:space-x-2 space-y-2 sm:space-y-0 w-full sm:w-auto mb-4 bg-transparent">
          <TabsTrigger value="account" className="flex items-center gap-2 justify-start px-4 py-2 data-[state=active]:bg-brand-50 data-[state=active]:text-brand-800">
            <Lock className="h-4 w-4" />
            Account Security
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2 justify-start px-4 py-2 data-[state=active]:bg-brand-50 data-[state=active]:text-brand-800">
            <Bell className="h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="display" className="flex items-center gap-2 justify-start px-4 py-2 data-[state=active]:bg-brand-50 data-[state=active]:text-brand-800">
            <Globe className="h-4 w-4" />
            Display & Accessibility
          </TabsTrigger>
          <TabsTrigger value="privacy" className="flex items-center gap-2 justify-start px-4 py-2 data-[state=active]:bg-brand-50 data-[state=active]:text-brand-800">
            <ShieldCheck className="h-4 w-4" />
            Privacy & Data
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="account">
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Change Password</CardTitle>
                <CardDescription>
                  Update your password to maintain account security
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handlePasswordChange} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <div className="relative">
                      <Input
                        id="current-password"
                        type={showCurrentPassword ? "text" : "password"}
                        placeholder="Enter your current password"
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      >
                        {showCurrentPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <div className="relative">
                      <Input
                        id="new-password"
                        type={showNewPassword ? "text" : "password"}
                        placeholder="Enter new password"
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                      >
                        {showNewPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Password must be at least 8 characters and include a mix of letters, numbers, and symbols.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <div className="relative">
                      <Input
                        id="confirm-password"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="Confirm new password"
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <Button type="submit" className="bg-brand-600 hover:bg-brand-700 text-white">
                    Update Password
                  </Button>
                </form>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Two-Factor Authentication</CardTitle>
                <CardDescription>
                  Add an extra layer of security to your account
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="space-y-0.5">
                    <div className="font-medium">Email Authentication</div>
                    <div className="text-sm text-muted-foreground">
                      Receive a verification code via email
                    </div>
                  </div>
                  <Switch
                    checked={true}
                    disabled
                  />
                </div>
                
                <Separator />
                
                <div className="flex justify-between items-center">
                  <div className="space-y-0.5">
                    <div className="font-medium">Mobile Authentication</div>
                    <div className="text-sm text-muted-foreground">
                      Receive a verification code via SMS
                    </div>
                  </div>
                  <Switch
                    checked={false}
                    onCheckedChange={(checked) => {
                      toast({
                        title: "Mobile authentication",
                        description: "Please set up your phone number to enable SMS authentication.",
                      });
                    }}
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Session Management</CardTitle>
                <CardDescription>
                  Manage your active sessions and devices
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-md p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-medium">Current Session</div>
                        <div className="text-sm text-muted-foreground mt-1">
                          Chrome on Windows • IP: 192.168.1.1
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          Started: {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
                        </div>
                      </div>
                      <div className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                        Active
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="destructive" 
                  className="w-full"
                  onClick={() => {
                    logout();
                    toast({
                      title: "Logged out",
                      description: "You have been logged out successfully.",
                    });
                  }}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out of All Devices
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>
                Manage how you receive notifications and updates
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Notification Channels</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium flex items-center">
                          <Mail className="h-4 w-4 mr-2" />
                          Email Notifications
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Receive notifications via email
                        </div>
                      </div>
                      <Switch
                        checked={notificationSettings.emailNotifications}
                        onCheckedChange={(checked) => handleNotificationSettingChange('emailNotifications', checked)}
                      />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium flex items-center">
                          <Bell className="h-4 w-4 mr-2" />
                          Push Notifications
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Receive notifications in your browser
                        </div>
                      </div>
                      <Switch
                        checked={notificationSettings.pushNotifications}
                        onCheckedChange={(checked) => handleNotificationSettingChange('pushNotifications', checked)}
                      />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium flex items-center">
                          <Smartphone className="h-4 w-4 mr-2" />
                          SMS Notifications
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Receive text messages for important updates
                        </div>
                      </div>
                      <Switch
                        checked={notificationSettings.smsNotifications}
                        onCheckedChange={(checked) => handleNotificationSettingChange('smsNotifications', checked)}
                      />
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Notification Types</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium">Registration Updates</div>
                        <div className="text-sm text-muted-foreground">
                          Changes to your course registration status
                        </div>
                      </div>
                      <Switch
                        checked={notificationSettings.registrationUpdates}
                        onCheckedChange={(checked) => handleNotificationSettingChange('registrationUpdates', checked)}
                      />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium">Payment Reminders</div>
                        <div className="text-sm text-muted-foreground">
                          Reminders about upcoming or due payments
                        </div>
                      </div>
                      <Switch
                        checked={notificationSettings.paymentReminders}
                        onCheckedChange={(checked) => handleNotificationSettingChange('paymentReminders', checked)}
                      />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium">Course Announcements</div>
                        <div className="text-sm text-muted-foreground">
                          Important announcements about your courses
                        </div>
                      </div>
                      <Switch
                        checked={notificationSettings.courseAnnouncements}
                        onCheckedChange={(checked) => handleNotificationSettingChange('courseAnnouncements', checked)}
                      />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium">General Updates</div>
                        <div className="text-sm text-muted-foreground">
                          University news and general information
                        </div>
                      </div>
                      <Switch
                        checked={notificationSettings.generalUpdates}
                        onCheckedChange={(checked) => handleNotificationSettingChange('generalUpdates', checked)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-brand-600 hover:bg-brand-700 text-white w-full">
                Save Notification Preferences
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="display">
          <Card>
            <CardHeader>
              <CardTitle>Display Settings</CardTitle>
              <CardDescription>
                Customize how the portal appears to you
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select
                    value={displaySettings.language}
                    onValueChange={(value) => handleDisplaySettingChange('language', value)}
                  >
                    <SelectTrigger id="language">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="hindi">Hindi</SelectItem>
                      <SelectItem value="telugu">Telugu</SelectItem>
                      <SelectItem value="tamil">Tamil</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="theme">Theme</Label>
                  <Select
                    value={displaySettings.theme}
                    onValueChange={(value) => handleDisplaySettingChange('theme', value)}
                  >
                    <SelectTrigger id="theme">
                      <SelectValue placeholder="Select theme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="system">System Default</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="font-size">Font Size</Label>
                  <Select
                    value={displaySettings.fontSize}
                    onValueChange={(value) => handleDisplaySettingChange('fontSize', value)}
                  >
                    <SelectTrigger id="font-size">
                      <SelectValue placeholder="Select font size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Accessibility</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium flex items-center">
                          <Moon className="h-4 w-4 mr-2" />
                          Compact View
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Reduce whitespace for denser content display
                        </div>
                      </div>
                      <Switch
                        checked={displaySettings.compactView}
                        onCheckedChange={(checked) => handleDisplaySettingChange('compactView', checked)}
                      />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <div className="font-medium flex items-center">
                          <Info className="h-4 w-4 mr-2" />
                          High Contrast
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Increase contrast for better visibility
                        </div>
                      </div>
                      <Switch
                        checked={displaySettings.highContrast}
                        onCheckedChange={(checked) => handleDisplaySettingChange('highContrast', checked)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-brand-600 hover:bg-brand-700 text-white w-full">
                Save Display Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="privacy">
          <Card>
            <CardHeader>
              <CardTitle>Privacy & Data Settings</CardTitle>
              <CardDescription>
                Manage your data and privacy preferences
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Data Sharing</h3>
                  <div className="flex justify-between items-center">
                    <div className="space-y-0.5">
                      <div className="font-medium">Share Academic Progress</div>
                      <div className="text-sm text-muted-foreground">
                        Share your academic performance with faculty
                      </div>
                    </div>
                    <Switch defaultChecked={true} />
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="space-y-0.5">
                      <div className="font-medium">Share Profile Information</div>
                      <div className="text-sm text-muted-foreground">
                        Allow other students to see your profile
                      </div>
                    </div>
                    <Switch defaultChecked={false} />
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Data Management</h3>
                  <p className="text-sm text-muted-foreground">
                    You can request a copy of your data or delete your account. Note that deleting your account will permanently remove all your data from our systems.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button variant="outline" className="w-full sm:w-auto">
                      Download My Data
                    </Button>
                    <Button variant="destructive" className="w-full sm:w-auto">
                      Delete My Account
                    </Button>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Third-Party Services</h3>
                  <p className="text-sm text-muted-foreground">
                    Manage how your data is shared with third-party services integrated with our portal.
                  </p>
                  
                  <div className="flex justify-between items-center">
                    <div className="space-y-0.5">
                      <div className="font-medium">Analytics Cookies</div>
                      <div className="text-sm text-muted-foreground">
                        Allow us to collect usage data to improve the portal
                      </div>
                    </div>
                    <Switch defaultChecked={true} />
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="space-y-0.5">
                      <div className="font-medium">Payment Processors</div>
                      <div className="text-sm text-muted-foreground">
                        Share data required for payment processing
                      </div>
                    </div>
                    <Switch defaultChecked={true} disabled />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-brand-600 hover:bg-brand-700 text-white w-full">
                Save Privacy Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
