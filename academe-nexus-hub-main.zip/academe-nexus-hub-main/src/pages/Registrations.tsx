
import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Check, X, Search, Filter, Calendar } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';

interface Registration {
  id: string;
  studentName: string;
  studentId: string;
  courseCode: string;
  courseName: string;
  registrationDate: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  type: 'Regular' | 'Backlog';
  paymentStatus: 'Paid' | 'Unpaid';
}

const Registrations = () => {
  const { toast } = useToast();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  
  const [registrations, setRegistrations] = useState<Registration[]>([
    { id: '1001', studentName: 'Rahul Sharma', studentId: 'S1001', courseCode: 'CS301', courseName: 'Database Management Systems', registrationDate: '2023-06-10', status: 'Pending', type: 'Regular', paymentStatus: 'Unpaid' },
    { id: '1002', studentName: 'Priya Patel', studentId: 'S1002', courseCode: 'CS401', courseName: 'Machine Learning', registrationDate: '2023-06-09', status: 'Approved', type: 'Regular', paymentStatus: 'Paid' },
    { id: '1003', studentName: 'Amit Kumar', studentId: 'S1003', courseCode: 'EE205', courseName: 'Digital Electronics', registrationDate: '2023-06-08', status: 'Rejected', type: 'Regular', paymentStatus: 'Paid' },
    { id: '1004', studentName: 'Kavita Singh', studentId: 'S1004', courseCode: 'ME102', courseName: 'Engineering Mechanics', registrationDate: '2023-06-07', status: 'Pending', type: 'Backlog', paymentStatus: 'Unpaid' },
    { id: '1005', studentName: 'Vikram Reddy', studentId: 'S1005', courseCode: 'CS301', courseName: 'Database Management Systems', registrationDate: '2023-06-06', status: 'Approved', type: 'Backlog', paymentStatus: 'Paid' },
    { id: '1006', studentName: 'Neha Gupta', studentId: 'S1006', courseCode: 'ME102', courseName: 'Engineering Mechanics', registrationDate: '2023-06-05', status: 'Pending', type: 'Regular', paymentStatus: 'Unpaid' },
    { id: '1007', studentName: 'Arjun Sharma', studentId: 'S1007', courseCode: 'CS401', courseName: 'Machine Learning', registrationDate: '2023-06-04', status: 'Rejected', type: 'Backlog', paymentStatus: 'Paid' },
  ]);

  const filterRegistrations = () => {
    let filtered = [...registrations];
    
    // For student users, only show their own registrations
    if (currentUser?.role === 'student') {
      filtered = filtered.filter(reg => reg.studentName === currentUser.name);
    }
    
    // Apply search query filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(reg => 
        reg.studentName.toLowerCase().includes(query) || 
        reg.courseCode.toLowerCase().includes(query) || 
        reg.courseName.toLowerCase().includes(query)
      );
    }
    
    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(reg => reg.status === statusFilter);
    }
    
    // Apply type filter
    if (typeFilter !== 'all') {
      filtered = filtered.filter(reg => reg.type === typeFilter);
    }
    
    return filtered;
  };

  const filteredRegistrations = filterRegistrations();

  const handleUpdateStatus = (regId: string, newStatus: 'Approved' | 'Rejected' | 'Pending') => {
    setRegistrations(prev => 
      prev.map(reg => 
        reg.id === regId ? { ...reg, status: newStatus } : reg
      )
    );
    
    const registration = registrations.find(r => r.id === regId);
    
    toast({
      title: `Registration ${newStatus.toLowerCase()}`,
      description: `${registration?.studentName}'s registration for ${registration?.courseName} has been ${newStatus.toLowerCase()}.`,
    });
  };

  const handleUpdatePayment = (regId: string, newStatus: 'Paid' | 'Unpaid') => {
    setRegistrations(prev => 
      prev.map(reg => 
        reg.id === regId ? { ...reg, paymentStatus: newStatus } : reg
      )
    );
    
    const registration = registrations.find(r => r.id === regId);
    
    toast({
      title: `Payment status updated`,
      description: `${registration?.studentName}'s payment for ${registration?.courseName} has been marked as ${newStatus.toLowerCase()}.`,
    });
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-brand-800">Course Registrations</h1>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Registration Requests</CardTitle>
          <CardDescription>
            {currentUser?.role === 'student' 
              ? 'View all your course registration requests and their status' 
              : 'Manage student course registration requests and approvals'}
          </CardDescription>
          
          <div className="flex flex-col md:flex-row gap-4 mt-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search by student or course..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="flex gap-2">
              <Select
                value={statusFilter}
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
              
              <Select
                value={typeFilter}
                onValueChange={setTypeFilter}
              >
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Regular">Regular</SelectItem>
                  <SelectItem value="Backlog">Backlog</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <Table>
            <TableCaption>
              {filteredRegistrations.length === 0 
                ? 'No registration requests found matching your criteria' 
                : `Total of ${filteredRegistrations.length} registration requests`}
            </TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Payment</TableHead>
                <TableHead>Status</TableHead>
                {(currentUser?.role === 'faculty' || currentUser?.role === 'admin') && (
                  <TableHead className="text-right">Actions</TableHead>
                )}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRegistrations.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={currentUser?.role === 'student' ? 6 : 7} className="text-center py-6 text-muted-foreground">
                    No registration requests found
                  </TableCell>
                </TableRow>
              ) : (
                filteredRegistrations.map(reg => (
                  <TableRow key={reg.id}>
                    <TableCell className="font-medium">
                      {reg.studentName}
                      <div className="text-xs text-muted-foreground">{reg.studentId}</div>
                    </TableCell>
                    <TableCell>
                      {reg.courseName}
                      <div className="text-xs text-muted-foreground">{reg.courseCode}</div>
                    </TableCell>
                    <TableCell>{reg.registrationDate}</TableCell>
                    <TableCell>
                      <Badge className={`
                        ${reg.type === 'Regular' ? 'bg-blue-100 text-blue-800' : ''}
                        ${reg.type === 'Backlog' ? 'bg-amber-100 text-amber-800' : ''}
                      `}>
                        {reg.type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {currentUser?.role === 'student' ? (
                        <Badge className={`
                          ${reg.paymentStatus === 'Paid' ? 'bg-green-100 text-green-800' : ''}
                          ${reg.paymentStatus === 'Unpaid' ? 'bg-red-100 text-red-800' : ''}
                        `}>
                          {reg.paymentStatus}
                        </Badge>
                      ) : (
                        <Select
                          defaultValue={reg.paymentStatus}
                          onValueChange={(value) => handleUpdatePayment(reg.id, value as 'Paid' | 'Unpaid')}
                        >
                          <SelectTrigger className="w-24 h-7 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Paid">
                              <span className="flex items-center">
                                <span className="h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                                Paid
                              </span>
                            </SelectItem>
                            <SelectItem value="Unpaid">
                              <span className="flex items-center">
                                <span className="h-2 w-2 rounded-full bg-red-500 mr-2"></span>
                                Unpaid
                              </span>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={`
                        ${reg.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' : ''}
                        ${reg.status === 'Approved' ? 'bg-green-100 text-green-800' : ''}
                        ${reg.status === 'Rejected' ? 'bg-red-100 text-red-800' : ''}
                      `}>
                        {reg.status}
                      </Badge>
                    </TableCell>
                    {(currentUser?.role === 'faculty' || currentUser?.role === 'admin') && (
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 text-green-600 hover:text-green-800"
                            onClick={() => handleUpdateStatus(reg.id, 'Approved')}
                            disabled={reg.status === 'Approved'}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 text-red-600 hover:text-red-800"
                            onClick={() => handleUpdateStatus(reg.id, 'Rejected')}
                            disabled={reg.status === 'Rejected'}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Registrations;
