
import React, { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Search, Mail, FileText, ExternalLink } from 'lucide-react';
import { useUsers } from '@/context/UserContext';
import { useRegistrations } from '@/context/RegistrationContext';
import { useBacklogs } from '@/context/BacklogContext';

const Students = () => {
  const { users } = useUsers();
  const { registrations } = useRegistrations();
  const { backlogs } = useBacklogs();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Get all students
  const students = users.filter(user => user.role === 'student');

  // Filter students based on search and status
  const filteredStudents = students.filter(student => 
    (student.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
     student.email.toLowerCase().includes(searchQuery.toLowerCase())) &&
    (statusFilter === 'all' || student.status === statusFilter)
  );

  // Calculate stats for each student
  const getStudentStats = (studentId: string) => {
    const studentRegistrations = registrations.filter(reg => reg.studentId === studentId);
    const studentBacklogs = backlogs.filter(backlog => backlog.studentId === studentId);
    
    return {
      registrations: studentRegistrations.length,
      approvedRegistrations: studentRegistrations.filter(reg => reg.status === 'approved').length,
      pendingRegistrations: studentRegistrations.filter(reg => reg.status === 'pending').length,
      backlogs: studentBacklogs.length,
      completedBacklogs: studentBacklogs.filter(backlog => backlog.status === 'completed').length
    };
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Student Management</h1>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Students</CardTitle>
          <CardDescription>
            View and manage all student information
          </CardDescription>
          
          <div className="flex flex-col sm:flex-row gap-4 mt-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search students..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Select
              value={statusFilter}
              onValueChange={setStatusFilter}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        
        <CardContent>
          <Table>
            <TableCaption>A list of all students in the system</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Registrations</TableHead>
                <TableHead>Backlogs</TableHead>
                <TableHead>Last Active</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-6 text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <FileText className="h-8 w-8 text-gray-400 mb-2" />
                      <p>No students found</p>
                      {searchQuery && (
                        <p className="text-sm text-gray-500 mt-1">Try adjusting your search criteria</p>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredStudents.map(student => {
                  const stats = getStudentStats(student.id);
                  return (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium">{student.name}</TableCell>
                      <TableCell>{student.email}</TableCell>
                      <TableCell>
                        <Badge className={
                          student.status === 'Active' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-800'
                        }>
                          {student.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{stats.approvedRegistrations}/{stats.registrations} approved</span>
                          {stats.pendingRegistrations > 0 && (
                            <span className="text-xs text-amber-600">{stats.pendingRegistrations} pending</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{stats.completedBacklogs}/{stats.backlogs} completed</span>
                          {stats.backlogs - stats.completedBacklogs > 0 && (
                            <span className="text-xs text-blue-600">{stats.backlogs - stats.completedBacklogs} in progress</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{student.lastActive}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="icon" className="h-8 w-8">
                            <Mail className="h-4 w-4" />
                          </Button>
                          <Button asChild variant="outline" size="icon" className="h-8 w-8">
                            <a href={`/student/${student.id}`}>
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Students;
