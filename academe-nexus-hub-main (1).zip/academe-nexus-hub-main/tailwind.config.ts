
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
				brand: {
					50: '#f0f7ff',
					100: '#ddecff',
					200: '#c0dfff',
					300: '#93cdff',
					400: '#5bb0ff',
					500: '#3b95ff',
					600: '#1a71f7',
					700: '#1259e8',
					800: '#1548bc',
					900: '#173f93',
					950: '#132758',
				},
				vignan: {
					primary: '#1a71f7',
					secondary: '#173f93',
					accent: '#e6ae00',
					light: '#f0f7ff',
					dark: '#132758',
				},
				vibrant: {
					pink: '#FF1493',
					purple: '#9400D3',
					indigo: '#4B0082',
					blue: '#0000FF',
					cyan: '#00FFFF',
					teal: '#008080',
					green: '#00FF00',
					lime: '#32CD32',
					yellow: '#FFFF00',
					amber: '#FFD700',
					orange: '#FFA500',
					red: '#FF0000',
				},
				pastel: {
					pink: '#FFD1DC',
					purple: '#E6E6FA',
					indigo: '#CCCCFF',
					blue: '#ADD8E6',
					cyan: '#AFEEEE',
					teal: '#AFEEEE',
					green: '#98FB98',
					lime: '#BFFF00',
					yellow: '#FFFACD',
					amber: '#FAFAD2',
					orange: '#FFEFD5',
					red: '#FFC0CB',
				},
				neon: {
					pink: '#FF6EC7',
					purple: '#C957FB',
					blue: '#5271FF',
					green: '#0FFF50',
					yellow: '#FFFF00',
					orange: '#FFD300',
					red: '#FF073A',
				},
				candy: {
					pink: '#FB91D1',
					purple: '#B387FF',
					blue: '#72BFFF',
					green: '#ADFF85',
					yellow: '#FFEF87',
					orange: '#FFB17A',
					red: '#FF9AA3',
				},
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				shimmer: {
					'100%': {
						transform: 'translateX(100%)',
					},
				},
				float: {
					'0%, 100%': { transform: 'translateY(0)' },
					'50%': { transform: 'translateY(-10px)' },
				},
				pulse: {
					'0%, 100%': { opacity: '1' },
					'50%': { opacity: '0.5' },
				},
				bounce: {
					'0%, 100%': { transform: 'translateY(0)' },
					'50%': { transform: 'translateY(-25%)' },
				},
				wiggle: {
					'0%, 100%': { transform: 'rotate(-3deg)' },
					'50%': { transform: 'rotate(3deg)' },
				},
				'gradient-x': {
					'0%, 100%': {
						'background-size': '200% 200%',
						'background-position': 'left center'
					},
					'50%': {
						'background-size': '200% 200%',
						'background-position': 'right center'
					}
				},
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'shimmer': 'shimmer 2s infinite',
				'float': 'float 3s ease-in-out infinite',
				'pulse': 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
				'bounce': 'bounce 1s infinite',
				'wiggle': 'wiggle 1s ease-in-out infinite',
				'gradient-x': 'gradient-x 3s ease infinite',
			},
			backgroundImage: {
				'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
				'gradient-candy': 'linear-gradient(to right, #ee9ca7, #ffdde1)',
				'gradient-ocean': 'linear-gradient(to right, #2e3192, #1bffff)',
				'gradient-sunset': 'linear-gradient(to right, #ff512f, #dd2476)',
				'gradient-mojito': 'linear-gradient(to right, #1d976c, #93f9b9)',
				'gradient-space': 'linear-gradient(to right, #3f5efb, #fc466b)',
				'gradient-neon': 'linear-gradient(to right, #12c2e9, #c471ed, #f64f59)',
				'gradient-dusk': 'linear-gradient(to right, #2c3e50, #fd746c)',
				'gradient-purple': 'linear-gradient(to right, #8e2de2, #4a00e0)',
				'gradient-emerald': 'linear-gradient(to right, #0ba360, #3cba92)',
				'gradient-golden': 'linear-gradient(to right, #f7971e, #ffd200)',
				'gradient-fire': 'linear-gradient(to right, #f5576c, #f093fb)',
			}
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
