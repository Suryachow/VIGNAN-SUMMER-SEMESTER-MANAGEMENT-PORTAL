
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback } from 'react';
import { User, UserRole } from '@/types';
import { toast } from 'sonner';

interface UserContextType {
  users: User[];
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (user: User) => void;
  deleteUser: (userId: string) => void;
  updateUserStatus: (userId: string, status: 'Active' | 'Inactive') => void;
  getUsersByRole: (role: UserRole) => User[];
  getUserById: (id: string) => User | undefined;
  isDataUpdated: boolean;
  refreshData: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isDataUpdated, setIsDataUpdated] = useState<boolean>(false);
  const [users, setUsers] = useState<User[]>([
    { 
      id: '1', 
      name: 'John Student', 
      email: 'student@example.com', 
      role: 'student', 
      status: 'Active', 
      lastActive: '2023-06-15',
      department: 'Computer Science',
      joinedDate: '2021-07-10',
      cgpa: 3.75
    },
    { 
      id: '2', 
      name: 'Jane Faculty', 
      email: 'faculty@example.com', 
      role: 'faculty', 
      status: 'Active', 
      lastActive: '2023-06-14',
      department: 'Computer Science',
      joinedDate: '2019-08-15'
    },
    { 
      id: '3', 
      name: 'Admin User', 
      email: 'admin@example.com', 
      role: 'admin', 
      status: 'Active', 
      lastActive: '2023-06-16',
      department: 'Administration',
      joinedDate: '2018-01-20'
    },
    { 
      id: '4', 
      name: 'Priya Sharma', 
      email: 'priya@example.com', 
      role: 'student', 
      status: 'Active', 
      lastActive: '2023-06-10',
      department: 'Electrical Engineering',
      joinedDate: '2022-07-15',
      cgpa: 3.9
    },
    { 
      id: '5', 
      name: 'Rahul Verma', 
      email: 'rahul@example.com', 
      role: 'student', 
      status: 'Inactive', 
      lastActive: '2023-05-20',
      department: 'Mechanical Engineering',
      joinedDate: '2021-07-10',
      cgpa: 3.4
    },
    { 
      id: '6', 
      name: 'Ananya Patel', 
      email: 'ananya@example.com', 
      role: 'faculty', 
      status: 'Active', 
      lastActive: '2023-06-12',
      department: 'Computer Science',
      joinedDate: '2020-01-15'
    },
    { 
      id: '7', 
      name: 'Vikram Singh', 
      email: 'vikram@example.com', 
      role: 'faculty', 
      status: 'Inactive', 
      lastActive: '2023-05-30',
      department: 'Electrical Engineering',
      joinedDate: '2019-07-20'
    },
  ]);

  // Check localStorage for users data
  useEffect(() => {
    const savedUsers = localStorage.getItem('academe_users');
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    }
  }, []);

  // Save to localStorage whenever users data changes
  useEffect(() => {
    localStorage.setItem('academe_users', JSON.stringify(users));
  }, [users]);

  const refreshData = useCallback(() => {
    setIsDataUpdated(prev => !prev);
  }, []);

  const addUser = useCallback((newUserData: Omit<User, 'id'>) => {
    const newUser = {
      ...newUserData,
      id: (users.length + 1).toString(),
    };
    
    setUsers(prev => {
      const updatedUsers = [...prev, newUser];
      localStorage.setItem('academe_users', JSON.stringify(updatedUsers));
      return updatedUsers;
    });
    
    toast.success(`New ${newUser.role} added: ${newUser.name}`);
    refreshData();
  }, [users, refreshData]);

  const updateUser = useCallback((updatedUser: User) => {
    setUsers(prev => {
      const updatedUsers = prev.map(user => user.id === updatedUser.id ? updatedUser : user);
      localStorage.setItem('academe_users', JSON.stringify(updatedUsers));
      return updatedUsers;
    });
    
    toast.success(`User updated: ${updatedUser.name}`);
    refreshData();
  }, [refreshData]);

  const deleteUser = useCallback((userId: string) => {
    const userToDelete = users.find(u => u.id === userId);
    
    setUsers(prev => {
      const updatedUsers = prev.filter(user => user.id !== userId);
      localStorage.setItem('academe_users', JSON.stringify(updatedUsers));
      return updatedUsers;
    });
    
    if (userToDelete) {
      toast.success(`User deleted: ${userToDelete.name}`);
    }
    refreshData();
  }, [users, refreshData]);

  const updateUserStatus = useCallback((userId: string, status: 'Active' | 'Inactive') => {
    setUsers(prev => {
      const updatedUsers = prev.map(user => 
        user.id === userId ? { ...user, status } : user
      );
      localStorage.setItem('academe_users', JSON.stringify(updatedUsers));
      return updatedUsers;
    });
    
    const user = users.find(u => u.id === userId);
    if (user) {
      toast.success(`${user.name}'s status updated to ${status}`);
    }
    refreshData();
  }, [users, refreshData]);

  const getUsersByRole = useCallback((role: UserRole): User[] => {
    return users.filter(user => user.role === role);
  }, [users]);

  const getUserById = useCallback((id: string): User | undefined => {
    return users.find(user => user.id === id);
  }, [users]);

  useEffect(() => {
    // This useEffect is intentional to trigger rerenders
    // when data changes are triggered across components
    console.log("User data updated");
  }, [isDataUpdated, users]);

  return (
    <UserContext.Provider value={{ 
      users, 
      addUser, 
      updateUser, 
      deleteUser, 
      updateUserStatus,
      getUsersByRole,
      getUserById,
      isDataUpdated,
      refreshData
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUsers = (): UserContextType => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUsers must be used within a UserProvider');
  }
  return context;
};
