
import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover:-translate-y-0.5 active:translate-y-0",
  {
    variants: {
      variant: {
        default: "bg-gradient-to-r from-primary to-accent text-primary-foreground hover:shadow-md",
        destructive:
          "bg-gradient-to-r from-destructive to-red-500 text-destructive-foreground hover:shadow-md",
        outline:
          "border border-input bg-background hover:bg-accent/10 hover:text-accent-foreground",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent/10 hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        brand: "bg-gradient-to-r from-brand-600 to-brand-500 text-white hover:shadow-md",
        purple: "bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:shadow-md",
        blue: "bg-gradient-to-r from-blue-500 to-cyan-400 text-white hover:shadow-md",
        green: "bg-gradient-to-r from-green-500 to-emerald-400 text-white hover:shadow-md",
        amber: "bg-gradient-to-r from-amber-500 to-yellow-400 text-white hover:shadow-md",
        rose: "bg-gradient-to-r from-rose-500 to-pink-400 text-white hover:shadow-md",
        colorful: "bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white hover:shadow-md",
        candy: "bg-gradient-candy text-white hover:shadow-md",
        ocean: "bg-gradient-ocean text-white hover:shadow-md",
        sunset: "bg-gradient-sunset text-white hover:shadow-md",
        mojito: "bg-gradient-mojito text-white hover:shadow-md",
        space: "bg-gradient-space text-white hover:shadow-md",
        glow: "bg-gradient-to-r from-primary to-accent text-primary-foreground hover:shadow-lg shadow-primary/40",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        xl: "h-12 rounded-md px-10 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
