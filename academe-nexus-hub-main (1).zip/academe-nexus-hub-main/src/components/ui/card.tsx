
import * as React from "react"

import { cn } from "@/lib/utils"

const Card = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & { 
    gradient?: boolean, 
    colorful?: boolean,
    glow?: boolean,
    glowColor?: 'blue' | 'purple' | 'green' | 'amber' | 'rose'
  }
>(({ className, gradient, colorful, glow, glowColor, ...props }, ref) => {
  const glowClasses = {
    blue: "card-glow",
    purple: "card-glow-purple",
    green: "card-glow-green",
    amber: "card-glow-amber",
    rose: "card-glow-rose",
  };

  return (
    <div
      ref={ref}
      className={cn(
        "rounded-lg border bg-card text-card-foreground shadow-sm transition-all duration-300",
        gradient && "bg-gradient-to-br from-card to-secondary/80",
        colorful && "bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 dark:from-indigo-900/20 dark:via-purple-900/20 dark:to-pink-900/20",
        glow && "hover:-translate-y-1",
        glow && glowColor && glowClasses[glowColor],
        glow && !glowColor && "card-glow",
        className
      )}
      {...props}
    />
  )
})
Card.displayName = "Card"

const CardHeader = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & { 
    colorVariant?: 'blue' | 'purple' | 'green' | 'amber' | 'rose' | 'colorful',
    bordered?: boolean,
    gradient?: boolean
  }
>(({ className, colorVariant, bordered, gradient, ...props }, ref) => {
  const gradientClasses = {
    blue: "gradient-blue text-white",
    purple: "gradient-purple text-white",
    green: "gradient-green text-white",
    amber: "gradient-amber text-white",
    rose: "gradient-rose text-white",
    colorful: "gradient-colorful text-white"
  };

  const softGradientClasses = {
    blue: "bg-gradient-to-r from-blue-50 to-cyan-50",
    purple: "bg-gradient-to-r from-purple-50 to-indigo-50",
    green: "bg-gradient-to-r from-green-50 to-emerald-50",
    amber: "bg-gradient-to-r from-amber-50 to-yellow-50",
    rose: "bg-gradient-to-r from-rose-50 to-pink-50",
    colorful: "bg-gradient-to-r from-indigo-50 via-purple-50 to-pink-50"
  };

  return (
    <div
      ref={ref}
      className={cn(
        "flex flex-col space-y-1.5 p-6 rounded-t-lg",
        colorVariant && !gradient && softGradientClasses[colorVariant],
        colorVariant && gradient && gradientClasses[colorVariant],
        bordered && "border-b",
        className
      )}
      {...props}
    />
  );
})
CardHeader.displayName = "CardHeader"

const CardTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement> & {
    gradient?: boolean,
    colorVariant?: 'blue' | 'purple' | 'green' | 'amber' | 'rose' | 'colorful'
  }
>(({ className, gradient, colorVariant, ...props }, ref) => {
  const gradientTextClasses = {
    blue: "text-gradient-blue",
    purple: "text-gradient-purple",
    colorful: "text-gradient-colorful",
    green: "bg-gradient-to-r from-green-600 to-emerald-500 bg-clip-text text-transparent",
    amber: "bg-gradient-to-r from-amber-600 to-yellow-500 bg-clip-text text-transparent",
    rose: "bg-gradient-to-r from-rose-600 to-pink-500 bg-clip-text text-transparent",
  };

  return (
    <h3
      ref={ref}
      className={cn(
        "text-2xl font-semibold leading-none tracking-tight",
        gradient && "text-gradient",
        gradient && colorVariant && gradientTextClasses[colorVariant],
        gradient && !colorVariant && "text-gradient-colorful",
        className
      )}
      {...props}
    />
  )
})
CardTitle.displayName = "CardTitle"

const CardDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
))
CardDescription.displayName = "CardDescription"

const CardContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & { padded?: 'sm' | 'lg' | 'xl' }
>(({ className, padded, ...props }, ref) => {
  const paddingClasses = {
    sm: "p-4 pt-0",
    lg: "p-8 pt-0",
    xl: "p-10 pt-0",
  };

  return (
    <div 
      ref={ref} 
      className={cn(
        "p-6 pt-0",
        padded && paddingClasses[padded],
        className
      )} 
      {...props} 
    />
  )
})
CardContent.displayName = "CardContent"

const CardFooter = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & { bordered?: boolean }
>(({ className, bordered, ...props }, ref) => (
  <div
    ref={ref}
    className={cn(
      "flex items-center p-6 pt-0", 
      bordered && "border-t mt-4 pt-4",
      className
    )}
    {...props}
  />
))
CardFooter.displayName = "CardFooter"

export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent }
