
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Search, Plus, Edit, Trash2, BookOpen } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { toast } from 'sonner';

interface Course {
  id: string;
  code: string;
  name: string;
  department: string;
  credits: number;
  capacity: number;
  registered: number;
  instructor: string;
  status: 'Open' | 'Filling Fast' | 'Closed';
  description: string;
}

const Courses = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [courses, setCourses] = useState<Course[]>([
    { 
      id: '1', 
      code: 'CS301', 
      name: 'Database Management Systems', 
      department: 'Computer Science', 
      credits: 4, 
      capacity: 60, 
      registered: 45, 
      instructor: 'Dr. Jane Faculty',
      status: 'Open',
      description: 'Fundamentals of database design, SQL, normalization, and transaction management.'
    },
    { 
      id: '2', 
      code: 'EE205', 
      name: 'Digital Electronics', 
      department: 'Electrical Engineering', 
      credits: 3, 
      capacity: 40, 
      registered: 38, 
      instructor: 'Prof. Ananya Patel',
      status: 'Filling Fast',
      description: 'Introduction to digital logic design, combinational and sequential circuits.'
    },
    { 
      id: '3', 
      code: 'ME102', 
      name: 'Engineering Mechanics', 
      department: 'Mechanical Engineering', 
      credits: 3, 
      capacity: 50, 
      registered: 32, 
      instructor: 'Dr. Vikram Singh',
      status: 'Open',
      description: 'Study of forces and their effects on engineering structures in static equilibrium.'
    },
    { 
      id: '4', 
      code: 'CS401', 
      name: 'Machine Learning', 
      department: 'Computer Science', 
      credits: 4, 
      capacity: 45, 
      registered: 45, 
      instructor: 'Dr. Jane Faculty',
      status: 'Closed',
      description: 'Introduction to machine learning algorithms, neural networks, and data analysis.'
    },
  ]);
  
  const [newCourse, setNewCourse] = useState<Omit<Course, 'id' | 'registered' | 'status'>>({
    code: '',
    name: '',
    department: '',
    credits: 3,
    capacity: 40,
    instructor: '',
    description: ''
  });
  
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);

  // Filter courses
  const filteredCourses = courses.filter(course => 
    (course.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
     course.code.toLowerCase().includes(searchQuery.toLowerCase())) &&
    (departmentFilter === 'all' || course.department === departmentFilter) &&
    (statusFilter === 'all' || course.status === statusFilter)
  );

  // Handle course click
  const handleCourseClick = (courseId: string) => {
    navigate(`/course/${courseId}`);
  };

  // Add new course
  const handleAddCourse = () => {
    const id = (courses.length + 1).toString();
    const courseToAdd = {
      ...newCourse,
      id,
      registered: 0,
      status: 'Open' as const
    };
    
    setCourses(prev => [...prev, courseToAdd]);
    setNewCourse({
      code: '',
      name: '',
      department: '',
      credits: 3,
      capacity: 40,
      instructor: '',
      description: ''
    });
    
    toast.success(`Course ${courseToAdd.code} added successfully`);
  };

  // Update course
  const handleUpdateCourse = () => {
    if (!editingCourse) return;
    
    setCourses(prev => 
      prev.map(course => 
        course.id === editingCourse.id ? editingCourse : course
      )
    );
    
    setEditingCourse(null);
    toast.success(`Course ${editingCourse.code} updated successfully`);
  };

  // Delete course
  const handleDeleteCourse = (courseId: string) => {
    const courseToDelete = courses.find(c => c.id === courseId);
    setCourses(prev => prev.filter(course => course.id !== courseId));
    
    if (courseToDelete) {
      toast.success(`Course ${courseToDelete.code} deleted successfully`);
    }
  };

  const isAdmin = currentUser?.role === 'admin';
  const isFaculty = currentUser?.role === 'faculty';
  const canManageCourses = isAdmin || isFaculty;

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Courses</h1>
        
        {canManageCourses && (
          <Dialog>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" /> Add Course
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[525px]">
              <DialogHeader>
                <DialogTitle>Add New Course</DialogTitle>
                <DialogDescription>
                  Fill in the details to add a new course to the system.
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="code">Course Code</Label>
                    <Input 
                      id="code" 
                      value={newCourse.code}
                      onChange={(e) => setNewCourse({...newCourse, code: e.target.value})}
                    />
                  </div>
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="name">Course Name</Label>
                    <Input 
                      id="name" 
                      value={newCourse.name}
                      onChange={(e) => setNewCourse({...newCourse, name: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="department">Department</Label>
                    <Input 
                      id="department" 
                      value={newCourse.department}
                      onChange={(e) => setNewCourse({...newCourse, department: e.target.value})}
                    />
                  </div>
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="credits">Credits</Label>
                    <Input 
                      id="credits" 
                      type="number"
                      value={newCourse.credits}
                      onChange={(e) => setNewCourse({...newCourse, credits: parseInt(e.target.value)})}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="capacity">Capacity</Label>
                    <Input 
                      id="capacity" 
                      type="number"
                      value={newCourse.capacity}
                      onChange={(e) => setNewCourse({...newCourse, capacity: parseInt(e.target.value)})}
                    />
                  </div>
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="instructor">Instructor</Label>
                    <Input 
                      id="instructor" 
                      value={newCourse.instructor}
                      onChange={(e) => setNewCourse({...newCourse, instructor: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="flex flex-col space-y-1.5">
                  <Label htmlFor="description">Description</Label>
                  <Input 
                    id="description" 
                    value={newCourse.description}
                    onChange={(e) => setNewCourse({...newCourse, description: e.target.value})}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <DialogClose asChild>
                  <Button onClick={handleAddCourse}>Add Course</Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Course Catalog</CardTitle>
          <CardDescription>
            Browse available courses for registration
          </CardDescription>
          
          <div className="flex flex-col md:flex-row gap-4 mt-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search courses..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Select
              value={departmentFilter}
              onValueChange={setDepartmentFilter}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                <SelectItem value="Computer Science">Computer Science</SelectItem>
                <SelectItem value="Electrical Engineering">Electrical Eng.</SelectItem>
                <SelectItem value="Mechanical Engineering">Mechanical Eng.</SelectItem>
              </SelectContent>
            </Select>
            
            <Select
              value={statusFilter}
              onValueChange={setStatusFilter}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="Open">Open</SelectItem>
                <SelectItem value="Filling Fast">Filling Fast</SelectItem>
                <SelectItem value="Closed">Closed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        
        <CardContent>
          <Table>
            <TableCaption>List of available courses for the current term</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Course Name</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Credits</TableHead>
                <TableHead className="text-center">Availability</TableHead>
                <TableHead className="text-center">Status</TableHead>
                {canManageCourses && <TableHead className="text-right">Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCourses.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={canManageCourses ? 7 : 6} className="text-center py-6 text-muted-foreground">
                    No courses found matching your criteria
                  </TableCell>
                </TableRow>
              ) : (
                filteredCourses.map((course) => (
                  <TableRow key={course.id} className="cursor-pointer hover:bg-slate-50" onClick={() => handleCourseClick(course.id)}>
                    <TableCell className="font-medium">{course.code}</TableCell>
                    <TableCell>{course.name}</TableCell>
                    <TableCell>{course.department}</TableCell>
                    <TableCell>{course.credits}</TableCell>
                    <TableCell className="text-center">
                      {course.registered}/{course.capacity}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge className={`
                        ${course.status === 'Open' ? 'bg-green-100 text-green-800' : ''}
                        ${course.status === 'Filling Fast' ? 'bg-amber-100 text-amber-800' : ''}
                        ${course.status === 'Closed' ? 'bg-red-100 text-red-800' : ''}
                      `}>
                        {course.status}
                      </Badge>
                    </TableCell>
                    {canManageCourses && (
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2" onClick={(e) => e.stopPropagation()}>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-[525px]">
                              <DialogHeader>
                                <DialogTitle>Edit Course</DialogTitle>
                                <DialogDescription>
                                  Update the course details
                                </DialogDescription>
                              </DialogHeader>
                              
                              {/* Edit course form would go here */}
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">Cancel</Button>
                                </DialogClose>
                                <DialogClose asChild>
                                  <Button onClick={handleUpdateCourse}>Save Changes</Button>
                                </DialogClose>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                          
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="icon" className="h-8 w-8">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Confirm Deletion</DialogTitle>
                                <DialogDescription>
                                  Are you sure you want to delete this course? This action cannot be undone.
                                </DialogDescription>
                              </DialogHeader>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">Cancel</Button>
                                </DialogClose>
                                <DialogClose asChild>
                                  <Button 
                                    variant="destructive" 
                                    onClick={() => handleDeleteCourse(course.id)}
                                  >
                                    Delete
                                  </Button>
                                </DialogClose>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Courses;
