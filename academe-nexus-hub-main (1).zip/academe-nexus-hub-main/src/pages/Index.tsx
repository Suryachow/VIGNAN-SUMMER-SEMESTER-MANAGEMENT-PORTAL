
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { 
  BookOpen, 
  GraduationCap, 
  Users, 
  FileCheck, 
  ArrowRight, 
  Calendar, 
  CreditCard,
  CheckCircle2,
  Bell,
  BarChart4,
  LayoutDashboard
} from 'lucide-react';
import { 
  Card, 
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface CourseStats {
  totalCourses: number;
  registeredStudents: number;
  completionRate: number;
  popularCourse: string;
}

interface Course {
  id: string;
  code: string;
  name: string;
  department: string;
  credits: number;
  available: number;
  registered: number;
  status: 'Open' | 'Filling Fast' | 'Closed';
}

interface Registration {
  id: string;
  studentName: string;
  course: string;
  date: string;
  status: 'Pending' | 'Approved' | 'Rejected';
}

const Index: React.FC = () => {
  const [courseStats, setCourseStats] = useState<CourseStats>({
    totalCourses: 42,
    registeredStudents: 523,
    completionRate: 78,
    popularCourse: "Advanced Data Structures"
  });
  
  const [upcomingCourses, setUpcomingCourses] = useState<Course[]>([
    { id: '1', code: 'CS301', name: 'Database Management Systems', department: 'Computer Science', credits: 4, available: 60, registered: 45, status: 'Open' },
    { id: '2', code: 'EE205', name: 'Digital Electronics', department: 'Electrical Eng.', credits: 3, available: 40, registered: 38, status: 'Filling Fast' },
    { id: '3', code: 'ME102', name: 'Engineering Mechanics', department: 'Mechanical Eng.', credits: 3, available: 50, registered: 32, status: 'Open' },
    { id: '4', code: 'CS401', name: 'Machine Learning', department: 'Computer Science', credits: 4, available: 45, registered: 45, status: 'Closed' },
  ]);
  
  const [recentRegistrations, setRecentRegistrations] = useState<Registration[]>([
    { id: '101', studentName: 'Priya Sharma', course: 'Database Management Systems', date: '2023-06-12', status: 'Approved' },
    { id: '102', studentName: 'Rahul Verma', course: 'Digital Electronics', date: '2023-06-11', status: 'Pending' },
    { id: '103', studentName: 'Ananya Patel', course: 'Engineering Mechanics', date: '2023-06-10', status: 'Approved' },
    { id: '104', studentName: 'Vikram Singh', course: 'Machine Learning', date: '2023-06-09', status: 'Rejected' },
  ]);
  
  useEffect(() => {
    const intervalId = setInterval(() => {
      setCourseStats(prev => ({
        ...prev,
        registeredStudents: prev.registeredStudents + Math.floor(Math.random() * 5),
        completionRate: Math.min(100, prev.completionRate + Math.floor(Math.random() * 2))
      }));
      
      setUpcomingCourses(prev => {
        const newCourses = [...prev];
        const randomIndex = Math.floor(Math.random() * newCourses.length);
        if (newCourses[randomIndex].registered < newCourses[randomIndex].available) {
          newCourses[randomIndex] = {
            ...newCourses[randomIndex],
            registered: newCourses[randomIndex].registered + 1,
            status: newCourses[randomIndex].registered + 1 >= newCourses[randomIndex].available ? 'Closed' : 
                   newCourses[randomIndex].registered + 1 >= newCourses[randomIndex].available * 0.8 ? 'Filling Fast' : 'Open'
          };
        }
        return newCourses;
      });
      
      if (Math.random() > 0.7) {
        const newStudent = {
          id: (100 + recentRegistrations.length + 1).toString(),
          studentName: ['Arjun Kumar', 'Sneha Reddy', 'Dev Patel', 'Meera Joshi'][Math.floor(Math.random() * 4)],
          course: upcomingCourses[Math.floor(Math.random() * upcomingCourses.length)].name,
          date: new Date().toISOString().split('T')[0],
          status: ['Pending', 'Approved', 'Rejected'][Math.floor(Math.random() * 2)] as 'Pending' | 'Approved' | 'Rejected'
        };
        
        setRecentRegistrations(prev => [newStudent, ...prev.slice(0, 3)]);
      }
    }, 15000);
    
    return () => clearInterval(intervalId);
  }, [upcomingCourses, recentRegistrations]);
  
  return (
    <div className="min-h-screen flex flex-col">
      <nav className="bg-brand-800 text-white shadow-md">
        <div className="container mx-auto px-6 py-4 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <img 
              src="/lovable-uploads/31072c56-aa73-4aa8-815e-345da39affb7.png"
              alt="Vignan University" 
              className="h-14 mr-4"
            />
            <div>
              <h1 className="text-2xl font-bold">Vignan University</h1>
              <p className="text-sm text-brand-300">Summer & Backlog Portal</p>
            </div>
          </div>
          <div className="flex gap-4 items-center">
            <Link to="/auth" className="text-white hover:text-brand-200 transition-colors">Sign In</Link>
            <Link to="/courses" className="text-white hover:text-brand-200 transition-colors">Courses</Link>
            <a href="#features" className="text-white hover:text-brand-200 transition-colors">Features</a>
            <a href="#dashboard-demo" className="text-white hover:text-brand-200 transition-colors">Live Dashboard</a>
            <a href="#contact" className="text-white hover:text-brand-200 transition-colors">Contact</a>
            <Button asChild variant="default" className="bg-white text-brand-800 hover:bg-gray-100">
              <Link to="/auth">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      <section className="bg-gradient-to-r from-brand-700 to-brand-600 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img 
            src="/lovable-uploads/138f0a39-7c9e-453d-aaab-b83bfe50251f.png" 
            alt="University Campus" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="container mx-auto px-6 text-center relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Vignan University Portal</h1>
          <p className="text-xl mb-10 max-w-2xl mx-auto">
            Complete summer course registrations and backlog management system with real-time updates and seamless data reflection.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button asChild size="lg" className="bg-white text-brand-600 hover:bg-gray-100 shadow-lg">
              <Link to="/auth" className="flex items-center gap-2">
                Get Started <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-10 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-2xl font-bold text-center mb-8 text-brand-800">Live Portal Statistics</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="bg-brand-50 p-6 rounded-lg shadow-sm">
              <div className="text-3xl font-bold text-brand-700">{courseStats.totalCourses}</div>
              <div className="text-brand-600">Total Courses</div>
            </div>
            <div className="bg-brand-50 p-6 rounded-lg shadow-sm relative overflow-hidden">
              <div className="text-3xl font-bold text-brand-700">{courseStats.registeredStudents}</div>
              <div className="text-brand-600">Registered Students</div>
              <div className="absolute top-1 right-1">
                <Badge variant="outline" className="bg-green-100 text-green-800 text-xs animate-pulse">Live</Badge>
              </div>
            </div>
            <div className="bg-brand-50 p-6 rounded-lg shadow-sm relative overflow-hidden">
              <div className="text-3xl font-bold text-brand-700">{courseStats.completionRate}%</div>
              <div className="text-brand-600">Completion Rate</div>
              <Progress className="mt-2" value={courseStats.completionRate} />
              <div className="absolute top-1 right-1">
                <Badge variant="outline" className="bg-green-100 text-green-800 text-xs animate-pulse">Live</Badge>
              </div>
            </div>
            <div className="bg-brand-50 p-6 rounded-lg shadow-sm">
              <div className="text-lg font-bold text-brand-700 truncate">{courseStats.popularCourse}</div>
              <div className="text-brand-600">Most Popular Course</div>
            </div>
          </div>
        </div>
      </section>

      <section id="dashboard-demo" className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-4 text-brand-800">Live Data Dashboard</h2>
          <p className="text-center text-brand-600 mb-12 max-w-3xl mx-auto">
            Experience how data is reflected in real-time across the portal
          </p>
          
          <Tabs defaultValue="courses" className="w-full max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="courses" className="text-lg">Upcoming Courses</TabsTrigger>
              <TabsTrigger value="registrations" className="text-lg">Recent Registrations</TabsTrigger>
              <TabsTrigger value="analytics" className="text-lg">Analytics</TabsTrigger>
            </TabsList>
            
            <TabsContent value="courses">
              <Card>
                <CardHeader>
                  <CardTitle>Summer Semester Course Availability</CardTitle>
                  <CardDescription>
                    Live view of course registrations - updates every few seconds
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableCaption>Showing {upcomingCourses.length} upcoming summer courses</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Course Code</TableHead>
                        <TableHead>Course Name</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Credits</TableHead>
                        <TableHead className="text-center">Availability</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {upcomingCourses.map(course => (
                        <TableRow key={course.id}>
                          <TableCell className="font-medium">{course.code}</TableCell>
                          <TableCell>{course.name}</TableCell>
                          <TableCell>{course.department}</TableCell>
                          <TableCell>{course.credits}</TableCell>
                          <TableCell className="text-center">
                            <div className="flex flex-col items-center">
                              <span>{course.registered}/{course.available}</span>
                              <Progress 
                                value={(course.registered / course.available) * 100} 
                                className="w-24 h-2 mt-1"
                              />
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge className={`
                              ${course.status === 'Open' ? 'bg-green-100 text-green-800' : ''}
                              ${course.status === 'Filling Fast' ? 'bg-amber-100 text-amber-800' : ''}
                              ${course.status === 'Closed' ? 'bg-red-100 text-red-800' : ''}
                            `}>
                              {course.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="registrations">
              <Card>
                <CardHeader>
                  <CardTitle>Latest Course Registrations</CardTitle>
                  <CardDescription>
                    Real-time updates of student registrations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableCaption>Last updated: {new Date().toLocaleTimeString()}</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student</TableHead>
                        <TableHead>Course</TableHead>
                        <TableHead>Registration Date</TableHead>
                        <TableHead className="text-right">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentRegistrations.map(reg => (
                        <TableRow key={reg.id}>
                          <TableCell className="font-medium">{reg.studentName}</TableCell>
                          <TableCell>{reg.course}</TableCell>
                          <TableCell>{reg.date}</TableCell>
                          <TableCell className="text-right">
                            <Badge className={`
                              ${reg.status === 'Approved' ? 'bg-green-100 text-green-800' : ''}
                              ${reg.status === 'Pending' ? 'bg-amber-100 text-amber-800' : ''}
                              ${reg.status === 'Rejected' ? 'bg-red-100 text-red-800' : ''}
                            `}>
                              {reg.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="analytics">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Registration Growth</CardTitle>
                    <CardDescription>
                      Daily registration count over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-80 flex items-center justify-center">
                    <div className="text-center text-brand-600">
                      <BarChart4 className="h-24 w-24 mx-auto mb-4 text-brand-500" />
                      <p>Interactive charts would display here</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        Sign in to view detailed analytics
                      </p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Course Completion</CardTitle>
                    <CardDescription>
                      Student progress tracking
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Database Management</span>
                          <span className="text-sm font-medium">65%</span>
                        </div>
                        <Progress value={65} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Digital Electronics</span>
                          <span className="text-sm font-medium">42%</span>
                        </div>
                        <Progress value={42} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Machine Learning</span>
                          <span className="text-sm font-medium">78%</span>
                        </div>
                        <Progress value={78} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Engineering Mechanics</span>
                          <span className="text-sm font-medium">91%</span>
                        </div>
                        <Progress value={91} className="h-2" />
                      </div>
                    </div>
                    
                    <div className="mt-8 text-center">
                      <Button variant="outline" className="mx-auto">
                        View Full Report
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <section id="features" className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-4 text-brand-800">Portal Features</h2>
          <p className="text-center text-brand-600 mb-12 max-w-3xl mx-auto">
            Our comprehensive platform provides everything you need to manage your academic journey
          </p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg text-center shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-brand-100 p-4 rounded-full inline-flex mb-4">
                <GraduationCap className="h-8 w-8 text-brand-600" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-brand-800">For Students</h3>
              <ul className="text-brand-600 space-y-2 text-left list-disc pl-5">
                <li>Register for summer courses</li>
                <li>View and manage backlog courses</li>
                <li>Track registration status</li>
                <li>Make secure payments</li>
                <li>Receive important notifications</li>
              </ul>
            </div>
            
            <div className="bg-white p-6 rounded-lg text-center shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-brand-100 p-4 rounded-full inline-flex mb-4">
                <Users className="h-8 w-8 text-brand-600" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-brand-800">For Faculty</h3>
              <ul className="text-brand-600 space-y-2 text-left list-disc pl-5">
                <li>Review and approve registrations</li>
                <li>Track student progress</li>
                <li>Manage course details</li>
                <li>Generate performance reports</li>
                <li>Communicate with students</li>
              </ul>
            </div>
            
            <div className="bg-white p-6 rounded-lg text-center shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-brand-100 p-4 rounded-full inline-flex mb-4">
                <FileCheck className="h-8 w-8 text-brand-600" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-brand-800">For Administrators</h3>
              <ul className="text-brand-600 space-y-2 text-left list-disc pl-5">
                <li>Manage course offerings</li>
                <li>Oversee registration process</li>
                <li>Track student payments</li>
                <li>Generate comprehensive reports</li>
                <li>Configure system settings</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-brand-800">Real-Time Data Features</h2>
          
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="flex flex-col items-center p-6 hover:shadow-md transition-all">
              <LayoutDashboard className="h-12 w-12 text-brand-600 mb-4" />
              <CardTitle className="text-lg font-bold text-center mb-2">Live Dashboard</CardTitle>
              <CardDescription className="text-center">
                Real-time updates on course registrations and approvals
              </CardDescription>
            </Card>
            
            <Card className="flex flex-col items-center p-6 hover:shadow-md transition-all">
              <Bell className="h-12 w-12 text-brand-600 mb-4" />
              <CardTitle className="text-lg font-bold text-center mb-2">Instant Notifications</CardTitle>
              <CardDescription className="text-center">
                Get alerts when your registration status changes
              </CardDescription>
            </Card>
            
            <Card className="flex flex-col items-center p-6 hover:shadow-md transition-all">
              <CheckCircle2 className="h-12 w-12 text-brand-600 mb-4" />
              <CardTitle className="text-lg font-bold text-center mb-2">Status Tracking</CardTitle>
              <CardDescription className="text-center">
                Monitor approval processes in real-time
              </CardDescription>
            </Card>
            
            <Card className="flex flex-col items-center p-6 hover:shadow-md transition-all">
              <CreditCard className="h-12 w-12 text-brand-600 mb-4" />
              <CardTitle className="text-lg font-bold text-center mb-2">Secure Payments</CardTitle>
              <CardDescription className="text-center">
                Instant payment verification and receipt generation
              </CardDescription>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-r from-brand-700 to-brand-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join our platform to experience real-time data updates and streamlined academic management.
          </p>
        </div>
      </section>

      <footer id="contact" className="bg-brand-800 text-white py-10 mt-auto">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl font-bold">Vignan University</h2>
              <p className="mt-2 text-brand-300">Empowering academic excellence</p>
              <div className="mt-4">
                <p className="text-brand-300">
                  Vadlamudi, Guntur District<br />
                  Andhra Pradesh, 522213
                </p>
                <p className="text-brand-300 mt-2">
                  Email: info@vignanuniversity.edu<br />
                  Phone: +91 9876543210
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-3">Portal</h3>
                <ul className="space-y-2">
                  <li><Link to="/" className="text-brand-300 hover:text-white">Home</Link></li>
                  <li><Link to="/courses" className="text-brand-300 hover:text-white">Courses</Link></li>
                  <li><Link to="/auth" className="text-brand-300 hover:text-white">Login</Link></li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-3">Resources</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-brand-300 hover:text-white">Documentation</a></li>
                  <li><a href="#" className="text-brand-300 hover:text-white">Help Center</a></li>
                  <li><a href="#" className="text-brand-300 hover:text-white">Contact Support</a></li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-3">Legal</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-brand-300 hover:text-white">Privacy Policy</a></li>
                  <li><a href="#" className="text-brand-300 hover:text-white">Terms of Service</a></li>
                  <li><a href="#" className="text-brand-300 hover:text-white">Cookie Policy</a></li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="border-t border-brand-700 mt-10 pt-6 text-center text-brand-300">
            <p>&copy; {new Date().getFullYear()} Vignan University. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
