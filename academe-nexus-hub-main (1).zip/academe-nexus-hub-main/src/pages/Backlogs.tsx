
import React, { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from "@/components/ui/dialog";
import { Search, Plus, FileText } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useBacklogs } from '@/context/BacklogContext';
import { useCourses } from '@/context/CourseContext';
import { useAuth } from '@/context/AuthContext';

const Backlogs = () => {
  const { toast } = useToast();
  const { backlogs, addBacklog, updateBacklogStatus } = useBacklogs();
  const { backlogCourses } = useCourses();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Filter backlogs based on user role and filters
  const getFilteredBacklogs = () => {
    let filteredList = backlogs;
    
    // Filter by user if student
    if (currentUser?.role === 'student') {
      filteredList = backlogs.filter(backlog => backlog.studentId === currentUser.id);
    }
    
    // Apply search filter
    filteredList = filteredList.filter(backlog => 
      backlog.courseName.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    // Apply status filter
    if (statusFilter !== 'all') {
      filteredList = filteredList.filter(backlog => backlog.status === statusFilter);
    }
    
    return filteredList;
  };

  const filteredBacklogs = getFilteredBacklogs();

  const handleAddBacklog = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const courseId = formData.get('courseId') as string;
    const studentId = currentUser?.role === 'student' 
      ? currentUser.id 
      : formData.get('studentId') as string;
    
    if (!courseId) {
      toast({
        title: "Error adding backlog",
        description: "Please select a course",
        variant: "destructive"
      });
      return;
    }
    
    const selectedCourse = backlogCourses.find(course => course.id === courseId);
    
    if (!selectedCourse) {
      toast({
        title: "Error adding backlog",
        description: "Selected course not found",
        variant: "destructive"
      });
      return;
    }
    
    addBacklog({
      studentId,
      courseId,
      courseName: selectedCourse.name,
      semester: formData.get('semester') as string || 'Current',
      academicYear: formData.get('academicYear') as string || '2023-2024',
      status: 'pending'
    }).then(() => {
      e.currentTarget.reset();
    });
  };

  const handleStatusChange = (backlogId: string, newStatus: string) => {
    updateBacklogStatus(backlogId, newStatus as any);
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Backlog Management</h1>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-brand-600 hover:bg-brand-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Add Backlog Course
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Backlog Course</DialogTitle>
              <DialogDescription>
                Register for a backlog course to clear previous subjects.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleAddBacklog} className="space-y-4">
              {currentUser?.role !== 'student' && (
                <div className="space-y-2">
                  <label htmlFor="studentId" className="text-sm font-medium">Student ID</label>
                  <Input id="studentId" name="studentId" placeholder="Enter student ID" required />
                </div>
              )}
              
              <div className="space-y-2">
                <label htmlFor="courseId" className="text-sm font-medium">Course</label>
                <Select name="courseId" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a course" />
                  </SelectTrigger>
                  <SelectContent>
                    {backlogCourses.map(course => (
                      <SelectItem key={course.id} value={course.id}>
                        {course.name} ({course.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="semester" className="text-sm font-medium">Semester</label>
                <Select name="semester" defaultValue="Current">
                  <SelectTrigger>
                    <SelectValue placeholder="Select semester" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Fall 2023">Fall 2023</SelectItem>
                    <SelectItem value="Spring 2024">Spring 2024</SelectItem>
                    <SelectItem value="Summer 2024">Summer 2024</SelectItem>
                    <SelectItem value="Current">Current</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="academicYear" className="text-sm font-medium">Academic Year</label>
                <Select name="academicYear" defaultValue="2023-2024">
                  <SelectTrigger>
                    <SelectValue placeholder="Select academic year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2022-2023">2022-2023</SelectItem>
                    <SelectItem value="2023-2024">2023-2024</SelectItem>
                    <SelectItem value="2024-2025">2024-2025</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="submit" className="bg-brand-600 hover:bg-brand-700 text-white">
                    Submit Backlog Request
                  </Button>
                </DialogClose>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Backlog Courses</CardTitle>
          <CardDescription>
            Manage all backlog course registrations
          </CardDescription>
          
          <div className="flex flex-col sm:flex-row gap-4 mt-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search courses..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Select
              value={statusFilter}
              onValueChange={setStatusFilter}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="registered">Registered</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        
        <CardContent>
          <Table>
            <TableCaption>A list of all backlog course registrations</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Course Name</TableHead>
                <TableHead>Semester</TableHead>
                <TableHead>Academic Year</TableHead>
                <TableHead>Status</TableHead>
                {currentUser?.role !== 'student' && <TableHead>Student ID</TableHead>}
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBacklogs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={currentUser?.role !== 'student' ? 6 : 5} className="text-center py-6 text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <FileText className="h-8 w-8 text-gray-400 mb-2" />
                      <p>No backlog courses found</p>
                      {searchQuery && (
                        <p className="text-sm text-gray-500 mt-1">Try adjusting your search criteria</p>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredBacklogs.map(backlog => (
                  <TableRow key={backlog.id}>
                    <TableCell className="font-medium">{backlog.courseName}</TableCell>
                    <TableCell>{backlog.semester}</TableCell>
                    <TableCell>{backlog.academicYear}</TableCell>
                    <TableCell>
                      {currentUser?.role !== 'student' ? (
                        <Select
                          defaultValue={backlog.status}
                          onValueChange={(value) => handleStatusChange(backlog.id, value)}
                        >
                          <SelectTrigger className="w-32 h-7 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="registered">Registered</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge className={`
                          ${backlog.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''}
                          ${backlog.status === 'registered' ? 'bg-blue-100 text-blue-800' : ''}
                          ${backlog.status === 'completed' ? 'bg-green-100 text-green-800' : ''}
                        `}>
                          {backlog.status.charAt(0).toUpperCase() + backlog.status.slice(1)}
                        </Badge>
                      )}
                    </TableCell>
                    {currentUser?.role !== 'student' && <TableCell>{backlog.studentId}</TableCell>}
                    <TableCell className="text-right">
                      <Button size="sm" variant="outline">
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Backlogs;
